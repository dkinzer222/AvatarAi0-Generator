---
layout: forward
target: https://developers.google.com/mediapipe/
title: Performance Benchmarking
parent: Tools
nav_order: 3
---

# Performance Benchmarking
{: .no_toc }

1. TOC
{:toc}
---

**Attention:** *Thanks for your interest in MediaPipe! We have moved to
[https://developers.google.com/mediapipe](https://developers.google.com/mediapipe)
as the primary developer documentation site for MediaPipe as of April 3, 2023.*

---

*Coming soon.*

Future mediapipe releases will include tools for visualizing and analysing the
latency histograms and timed events captured for performance benchmarking.
