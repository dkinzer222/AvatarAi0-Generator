# MediaPipeTasksDocGen

This empty project is used to generate reference documentation for the
ObjectiveC and Swift libraries.

Docs are generated using [Jazzy](https://github.com/realm/jazzy) and published
to [the developer site](https://developers.google.com/mediapipe/solutions/).

To bump the API version used, edit [`Podfile`](./Podfile).
