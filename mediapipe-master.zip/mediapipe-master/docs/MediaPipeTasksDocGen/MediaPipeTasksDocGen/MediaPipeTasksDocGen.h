//
//  MediaPipeTasksDocGen.h
//  MediaPipeTasksDocGen
//
//  Created by Mark McDonald on 20/9/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for MediaPipeTasksDocGen.
FOUNDATION_EXPORT double MediaPipeTasksDocGenVersionNumber;

//! Project version string for MediaPipeTasksDocGen.
FOUNDATION_EXPORT const unsigned char MediaPipeTasksDocGenVersionString[];

// In this header, you should import all the public headers of your framework using statements like
// #import <MediaPipeTasksDocGen/PublicHeader.h>
